import os
import random
import time
def cls():
    os.system('clear')

def makeman():
    cls()
    print("       _____                   _____           ")
    print("      /  0 0\                 /0 0  \ ")
    print("      |   _ |                 | _   |")
    print("       \___/                   \___/ "   )
    print("        ||                       ||")
    print("       /  \                     /  \ ")
    print("       |  |                     |  |")
    
    
def makemanshoot1():
    cls()
    print("       _____                   _____           ")
    print("      /  0 0\                 /0 0  \ ")
    print("      |   _ |                 | _   |")
    print("       \___/    ___            \___/ "   )
    print("        || ____|                 ||")
    print("       /  \                     /  \ ")
    print("       |  |                     |  |")
    
def makemanshoot2():
    cls()
    print("       _____                   _____           ")
    print("      /  0 0\                 /0 0  \ ")
    print("      |   _ |                 | _   |")
    print("       \___/            ___    \___/ "   )
    print("        ||                 |____ ||")
    print("       /  \                     /  \ ")
    print("       |  |                     |  |")
    
    
def makemanp1d():
    cls()
    print("       ____                    _____           ")
    print("      / x   x\                /0 0  \ ")
    print("       |    |                 | _   |")
    print("       __-/             ___    \___/ "   )
    print("        |                  |____ ||")
    print("      / \                       /  \ ")
    print("       |  |                     |  |")
    
def makemanp2d():
    cls()
    print("       _____                   __           ")
    print("      /  0 0\                 /x    x  \ ")
    print("      |   _ |                 |")
    print("       \___/     ___           \ __/ "   )
    print("        || _____|                 ||")
    print("       /  \                     /\ ")
    print("       |  |                     |       |")
    
def makemanfear1():
    cls()
    print("       _____                   _____           ")
    print("      /  o o\___              /0 0  \ ")
    print("      |   _ |   |             | _   |")
    print("       \___/   /               \___/ "   )
    print("        || ___/                  ||")
    print("       /  \                     /  \ ")
    print("       |  |                     |  |")
    
def makemanfear2():
    cls()
    print("       _____                   _____           ")
    print("      /  0 0\              ___/o o  \ ")
    print("      |   _ |             |   | _   |")
    print("       \___/               \   \___/ "   )
    print("        ||                  \___ ||")
    print("       /  \                     /  \ ")
    print("       |  |                     |  |")
    
def makemandow1():
    cls()
    print("       ____                    _____           ")
    print("      / x   x\                /0 0  \ ")
    print("       |    |                 | _   |")
    print("       __-/                    \___/ "   )
    print("        |                        ||")
    print("      / \                       /  \ ")
    print("       |  |                     |  |")
    
def makemandow2():
    cls()
    print("       _____                   __           ")
    print("      /  0 0\              /    x  \ ")
    print("      |   _ |               x      |")
    print("       \___/                  \ __/ "   )
    print("        ||                      ||")
    print("       /  \                     /\ ")
    print("       |  |                     |")